﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace CodeDocs
{
    public abstract class CodeBasedAttribute : Attribute
    {

        protected CodeBasedAttribute(string details, Risk risk, Effort effort, string tags, string[] urls)
        {
            this.Risk = risk;
            this.Effort = effort;
            this.Details = details;
            this.Tags = SplitToTags(tags);
            this.Urls = urls;
        }


        public abstract Definition Definition { get; }


        public readonly Risk Risk;

        public readonly Effort Effort;

        public readonly string Details;

        public readonly string[] Tags;

        public readonly string[] Urls;

        public static string[] SplitToTags(string tags)
        {
            return string.IsNullOrEmpty(tags) ? new string[0] : tags.Replace(", ", ",").Split(',');
        }

    }
}
