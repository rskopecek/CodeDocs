﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeDocs.Definitions.Specifics;

namespace CodeDocs
{
    public static class Glossary
    {
        public static List<Definition> Definitions()
        {
            return new List<Definition>
            {
                Bug, Hack, Refactor, Test, Naming, 
                Todo, Location, Purpose, Readability, Cite,
                Feature, MajorChange, MinorChange, MajorFix, MinorFix,
                Future, Standards, Slow, Security, InSecure, Toxic, Consequence, DeadCode
            };
        }

        public static IEnumerable<string> Tags(this IEnumerable<Definition> definitions)
        {
            return definitions.SelectMany(i => i.Tags).Distinct();
        }

        #region Definition Specifics

        public static readonly Definition Bug = new BugDefinition();
        public static readonly Definition Hack = new HackDefinition();
        public static readonly Definition Refactor = new RefactorDefinition();
        public static readonly Definition Test = new TestDefinition();
        public static readonly Definition Naming = new NamingDefinition();
        public static readonly Definition Purpose = new PurposeDefinition();
        public static readonly Definition Readability = new ReadabilityDefinition();
        public static readonly Definition Clarification = new ClarificationDefinition();
        public static readonly Definition Location = new LocationDefinition();
        public static readonly Definition Cite = new CiteDefinition();
        public static readonly Definition Todo = new TodoDefinition();
        public static readonly Definition Future = new FutureDefinition();
        public static readonly Definition Feature = new FeatureDefinition();
        public static readonly Definition MajorChange = new MajorChangeDefinition();
        public static readonly Definition MinorChange = new MinorChangeDefinition();
        public static readonly Definition MajorFix = new MajorFixDefinition();
        public static readonly Definition MinorFix = new MinorFixDefinition();
        public static readonly Definition Standards = new StandardsDefinition();
        public static readonly Definition Slow = new SlowDefinition();
        public static readonly Definition Security = new SecurityDefinition();
        public static readonly Definition InSecure = new InSecureDefinition();
        public static readonly Definition Toxic = new ToxicDefinition();
        public static readonly Definition Consequence = new ConsequenceDefinition();
        public static readonly Definition DeadCode = new DeadCodeDefinition();

        #endregion

    }
}
